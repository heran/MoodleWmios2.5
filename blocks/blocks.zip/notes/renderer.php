<?php

class block_notes_renderer extends plugin_renderer_base {
    
    public function render_notes_box(){
        return '';
    }
}