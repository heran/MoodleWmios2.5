<?php

/**
 * Version details
 *
 * @package    block
 * @subpackage notes
 * @copyright  2013 Wmios (http://wmios.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();


$plugin->version      = 2013042000; // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires     = 2012112900; // Requires this Moodle version
$plugin->component    = 'block_notes';
$plugin->dependencies = array('local_wmios' => 2013031100);
