<?php

class restore_notes_block_structure_step extends restore_structure_step {

    protected function define_structure() {
        
        $paths = array();
        
        //When no user info, we need not restore this.
        
        /** @var backup_users_setting */
        if($this->get_task()->get_plan_setting_value('users')){
            $paths[] = new restore_path_element('note', '/block/combos/notes/note');
            $paths[] = new restore_path_element('completion', '/block/combos/completions/completion');
        }
        return $paths;
    }

    public function process_note($data) {
        global $DB;
        
        $data = (object)$data;
        
        $oldid = $data->id;
        unset($data->id);
        
        $data->courseid = $this->get_courseid();
        $data->userid = $this->get_mappingid('user', $data->userid);
        $data->modifiedtime = $this->apply_date_offset($data->modifiedtime);
        
        $newitemid = $DB->insert_record('notes', $data);
        
    }
    
    public function process_completion($data) {
        global $DB;
        
        $data = (object)$data;
        
        $oldid = $data->id;
        unset($data->id);
        
        $data->courseid = $this->get_courseid();
        $data->userid = $this->get_mappingid('user', $data->userid);
        $data->timemodified = $this->apply_date_offset($data->timemodified);
        
        $newitemid = $DB->insert_record('course_modules_comple_ratio', $data);
        
    }
}
