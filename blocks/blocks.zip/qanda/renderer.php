<?php

class block_qanda_renderer extends plugin_renderer_base {
    
    
    /**
    * Block main content
    * 
    */
    public function render_qanda_box(){
        return '';
    }
}