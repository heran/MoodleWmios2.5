<?php

/**
 * Theme version info
 *
 * @package    theme
 * @subpackage udemy
 * @copyright  2010 Wmios (http://wmios.com/)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$plugin->version   = 2013030100; // The current module version (Date: YYYYMMDDXX)

//Do not change
$plugin->requires  = 2012112900; // Requires this Moodle version

$plugin->component = 'theme_udemy'; // Full name of the plugin (used for diagnostics)
