$(function(){
    $('.path-user .mform input[name=submitbutton]').addClass('btn btn-success');
});