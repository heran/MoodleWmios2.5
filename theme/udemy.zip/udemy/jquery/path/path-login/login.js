$(function(){
    $('#page-login-change_password .mform input[name=submitbutton]').addClass('btn btn-success');
    $('#page-login-change_password .mform input[name=cancel]').addClass('btn btn-danger');
});