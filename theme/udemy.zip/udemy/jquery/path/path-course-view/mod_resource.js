//

var M = M || {};
M.W = M.W || {};
M.W.modview = M.W.modview || {};
M.W.modview.modhandler = M.W.modview.modhandler || {};

M.W.modview.modhandler.resource =resource_mod_view = {
    support:{goto_and_play:false,get_now_position:false,resume_mod:false},
    load_modview:function(cmid,content_box,intro_box,callback){
        var resize=function(){
            var mh=$('.mod-resource-content').height();
            var miaoshu=$('.mod-resource-content .resource-intro').height();
            var stype=$('.mod-resource-content .resource-stype').height();
            var cha=$('.mod-resource-content .resource-cha').height();
            var ifram=mh-miaoshu-stype-cha;

            $('.mod-resource-content .resource-content iframe').height(ifram);
        }

        $(window).resize(resize);
        $.get(M.cfg.wwwroot+'/mod/resource/view.php',{id:cmid},function(data){

            data = $(data);

            var title=$(data).find('div[role=main]>#resourceheading').text();
            var miaoshu=$(data).find('div[role=main]>#resourceintro .no-overflow').html();
            var stype=$(data).find('div[role=main]>#resourceintro .resourcedetails').text();
            var content=$(data).find('div[role=main]>.resourcecontent.resourcegeneral').html();
            var cha=$(data).find('div[role=main]>.resourceworkaround').html();
            var files=$(data).find('div[role=main]>.resourcecontent.resourceimg').html();

            var html='<div class="mod-resource-content">';
            if($(data).find('div[role=main]>#resourceheading').length>0){
                html +='<div class="mod-resource-title">'+title+'</div>';    
            }
            
            if($(data).find('div[role=main]>.resourcecontent.resourceimg').length>0){
                
                html +='<div class="resource-file"><div>'+files+'</div></div>';
            }

            if($(data).find('div[role=main]>.resourcecontent.resourcegeneral').length>0){
                html +='<div class="resource-content">'+content+'</div>'; 

            }

            if($(data).find('div[role=main]>#resourceintro').length>0){
                html +='<div class="resource-intro">'+miaoshu+'</div>'; 
                html +='<div class="resource-stype">'+stype+'</div>';   
            }

            if($(data).find('div[role=main]>.resourceworkaround').length>0){

                html +='<div class="resource-cha">'+cha+'</div>';
            }

            html +='</div>';

            $(content_box).html(html);

            resize();

            callback(cmid);

        });

    }



}

