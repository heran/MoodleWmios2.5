<?php
$strings[] = array('category','core');
$strings[] = array('all_a_category','theme_udemy');
$strings[] = array('nocoursesfound','core');
