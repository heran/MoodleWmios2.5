$(function(){
    $('input[type=submit]').addClass('btn btn-success');
})