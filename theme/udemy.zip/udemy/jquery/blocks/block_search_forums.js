//path /theme/udemy/javascript/must/block_search_forums
$(function(){
    /*******************block搜索讨论区样式*****************************/
    var html=$(".block_search_forums.block .content").html();

    var h2t=$('.block_search_forums.block .title').text();

    $('.block_search_forums.block .block-header').html(html);


    $(".block_search_forums.block .searchform").find("br").remove();


    $(".block_search_forums.block fieldset button").html("");
    $(".block_search_forums.block fieldset button").addClass("icon-search");


    $(".block_search_forums.block input[name='search']").attr("placeholder",h2t);

    $(".block_search_forums.block .content").remove();

    

});

