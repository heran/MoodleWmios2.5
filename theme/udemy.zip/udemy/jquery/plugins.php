<?php

$plugins = theme_udemy_jquery_plugins();