<?php
  die();
?>
This theme is copied from /theme/binarius by Heran At 2012-12-21 15:02:25.

