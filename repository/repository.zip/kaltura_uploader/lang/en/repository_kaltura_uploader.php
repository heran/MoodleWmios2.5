<?php

$string['configplugin'] = 'Configuration for Kaltura uploader plug-in';
$string['pluginname_help'] = 'Upload media to Kaltura';
$string['pluginname'] = 'Upload media to Kaltura';

// errors
$string['upload_kaltura_error_process_upload'] = 'There was an error uploading the file to Kaltura';

// Capabilities
$string['kaltura_uploader:view'] = 'View Kaltura uploader repo';