<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'questionnaire', language 'zh_cn', branch 'MOODLE_25_STABLE'
 *
 * @package   questionnaire
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['alreadyfilled'] = '您已经完成我们的问卷调查，谢谢您的参与。';
$string['modulename'] = '问卷调查';
$string['modulenameplural'] = '问卷调查';
$string['mustcomplete'] = '<b>你必须<i>马上</i>完成这个问卷调查才能记录您的结果。你不能在其它时间去完成它。</b><br /><br />';
$string['notavail'] = '此问卷暂时不能使用，请稍后再试。';
$string['qmanage'] = '管理调查';
$string['qmanagetitle'] = '管理phpESP的问卷';
$string['qtype'] = '填写次数限制';
$string['questionnaireid'] = '调查';
$string['respondenttype'] = '调查问卷类型';
